from random import randint
 
n = int(input("Количество чисел для сортировки: "))
massive = [randint(0, 100) for i in range(n)]
print(f"Неотсортированный массив - {massive}")
for i in range (n-1) :
    for j in range(n-1):
        if massive[j] > massive[j+1]:
            massive[j], massive[j+1] = massive[j+1], massive[j]
print(f"Отсортированный массив - {massive}")

