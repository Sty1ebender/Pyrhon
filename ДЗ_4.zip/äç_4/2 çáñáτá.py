dict = {'Red' : (255, 0, 0), 'Green' : (0, 128, 0),
        'Blue' : (0, 0, 255), 'Magenta' :(255, 0, 255), 'Black' : (0, 0, 0),
        'White': (255, 255, 255), 'DarkRed' : (139, 0, 0), 'Navy' : (0, 0, 128),
        'ForestGreen' : (34, 139, 34), 'Cyan' : (0, 255, 255), 'Yellow' : (255, 255, 0),
        'Purple' : (128, 0, 128), 'Gray' : (128, 128, 128), 'Silver' : (192, 192, 192),
        'Orange' : (255, 165, 0), 'Aqua' : (0, 255, 255)}
Color = input("Введите название цвета: ")
if Color in dict.keys():
    print(dict[Color])
