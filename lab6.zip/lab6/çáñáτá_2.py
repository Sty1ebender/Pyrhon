from random import randint
c, h, o = randint(100,1000), randint(100,1000), randint(100,1000)

molecules_file = open("molecules.txt", "w")
molecules_file.write(f"{c} {h} {o}")
molecules_file.close()

molecules_read = open("molecules.txt", "r")
values = molecules_read.read().split(" ")
for i in range(len(values)):
    if i == 0:
        c_count = int(values[i]) // 2
    elif i == 1:
        h_count = int(values[i]) // 6

answer_file = open("answer.txt", "w")
answer_file.write(str(min(c_count, h_count, o)))
answer_file.close()
