import random
import string

random_length = random.randint(10, 20)
xor_file = open("xor_file", "w", encoding="utf-8")
xor_file.write("""В осеннем лесу, на развилке дорог,
Стоял я, задумавшись, у поворота;
Пути было два, и мир был широк,
Однако я раздвоиться не мог,
И надо было решаться на что-то.

Я выбрал дорогу, что вправо вела
И, повернув, пропадала в чащобе.
Нехоженей, что ли, она была
И больше, казалось мне, заросла;
А впрочем, заросшими были обе.

И обе манили, радуя глаз
Сухой желтизною листвы сыпучей.
Другую оставил я про запас,
Хотя и догадывался в тот час,
Что вряд ли вернуться выпадет случай.

Еще я вспомню когда-нибудь
Далекое это утро лесное:
Ведь был и другой предо мною путь,
Но я решил направо свернуть —
И это решило все остальное. \n\n""")

letters = string.ascii_lowercase
rand_string = ''.join(random.choice(letters) for i in range(random_length))
xor_file.write(f"XOR code: {rand_string}")
xor_file.close()

xor = open("xor_file", "r", encoding="utf-8")

xor_lines = xor.readlines()
xor_string = xor_lines[-1][xor_lines[-1].rfind(" ") + 1:]


# Работает на шифровку и дешифровку
def xor_function(str, key):
    from itertools import cycle
    cycler = cycle(key)
    encript_str = ""
    for letter in str:
        encript_str += chr(ord(letter) ^ ord(next(cycler)))
    return encript_str


for i in range(len(xor_lines) - 1):
    if xor_lines[i].strip() == "":
        print("")
    else:
        print(xor_function(xor_lines[i], xor_string))

