def sumNumbers(myMassive):
    sum = 0
    for i in myMassive:
        sum += i
    return sum
numbers = map(int, input("Введите числа: ").split())
print(sumNumbers(numbers))