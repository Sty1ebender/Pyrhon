def password(passw):
    return ((len(passw) >= 6) and (not passw.isdigit()) and (any(map(str.isdigit, passw))) and (not "password" in passw.casefold()))
passwordFirst = input('Введите, пароль: ')
print(password(passwordFirst))
